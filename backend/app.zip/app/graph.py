"""Simplified self-healing workflow.

Instead of guessing a whole adversarial test suite (which requires inferring
which raised exceptions are "intended" -- a problem that has no good answer
without a human-specified contract), this graph validates ONE concrete call:
either supplied by the caller, or, if omitted, a single representative call
chosen by an LLM that is explicitly told to avoid boundary/error-inducing
inputs. A failing call triggers a Fixer LLM repair proposal, gated behind
human approval, followed by regression on that same call.

ChromaDB memory is optional and best-effort (see memory.py): it can add
context to the Fixer's prompt, but it can never affect control flow or
block a run.
"""
import ast
import inspect
import json
import re
from typing import Any, Callable, Dict, List, Optional

from langchain_core.messages import HumanMessage
from langgraph.checkpoint.memory import MemorySaver
from langgraph.graph import END, StateGraph
from pydantic import BaseModel, Field

from .executor import run_call
from .llm import get_fixer_llm, get_tester_llm
from .memory import recent_patterns, save_bug_pattern
from .prompts import FIXER_SYSTEM, SMOKE_CALL_SYSTEM

MAX_ITERATIONS_DEFAULT = 5


class HealingState(BaseModel):
    function_name: str
    function_string: str

    args: List[Any] = Field(default_factory=list)
    kwargs: Dict[str, Any] = Field(default_factory=dict)
    # "user": caller supplied the call.
    # "auto_pending": needs call_selection_node to pick one via the Tester LLM.
    # "auto": call_selection_node already picked one.
    args_source: str = "user"

    error: bool = False
    error_description: str = ""
    new_function_string: str = ""

    iterations: int = 0
    max_iterations: int = MAX_ITERATIONS_DEFAULT

    status: str = "running"
    result: Optional[str] = None
    log: List[str] = Field(default_factory=list)

    tester_model: str = ""
    fixer_model: str = ""


def _log(state: HealingState, message: str) -> None:
    print(message)
    state.log.append(message)


def _load_callable(function_string: str, function_name: str) -> Callable:
    namespace: Dict[str, Any] = {}
    exec(function_string, {"__builtins__": __builtins__}, namespace)  # noqa: S102
    fn = namespace.get(function_name)
    if not callable(fn):
        raise ValueError(f"No function named '{function_name}' was defined by the given source.")
    return fn


def _extract_function(code: str) -> tuple[str, str]:
    tree = ast.parse(code)
    funcs = [n for n in tree.body if isinstance(n, ast.FunctionDef)]
    if len(funcs) != 1:
        raise ValueError("Please submit exactly one top-level Python function.")
    segment = ast.get_source_segment(code, funcs[0])
    if not segment:
        raise ValueError("Could not recover the function source.")
    return funcs[0].name, segment


def _strip_code_fences(text: str) -> str:
    text = text.strip()
    text = re.sub(r"^```(?:python)?\s*", "", text, flags=re.I)
    text = re.sub(r"\s*```$", "", text)
    return text.strip()


def _extract_json(text: str) -> dict:
    """Pull a JSON object out of an LLM response, tolerating stray prose/fences."""
    text = text.strip()
    try:
        data = json.loads(text)
        if isinstance(data, dict):
            return data
    except json.JSONDecodeError:
        pass

    start = text.find("{")
    if start >= 0:
        depth = 0
        in_string = False
        escape = False
        for i in range(start, len(text)):
            ch = text[i]
            if in_string:
                if escape:
                    escape = False
                elif ch == "\\":
                    escape = True
                elif ch == '"':
                    in_string = False
            else:
                if ch == '"':
                    in_string = True
                elif ch == "{":
                    depth += 1
                elif ch == "}":
                    depth -= 1
                    if depth == 0:
                        try:
                            data = json.loads(text[start:i + 1])
                            if isinstance(data, dict):
                                return data
                        except json.JSONDecodeError:
                            break
    raise ValueError("Expected a JSON object in the model's response but could not find one.")


def _validate_arity(function_string: str, function_name: str, args: list, kwargs: dict) -> None:
    fn = _load_callable(function_string, function_name)
    try:
        inspect.signature(fn).bind(*args, **kwargs)
    except TypeError as e:
        raise ValueError(f"Call does not match '{function_name}'s signature: {e}") from e


def guess_smoke_call(function_name: str, function_string: str) -> Dict[str, Any]:
    """Ask the Tester LLM for ONE typical, non-adversarial call. One LLM round-trip."""
    prompt = f"""{SMOKE_CALL_SYSTEM}

FUNCTION NAME:
{function_name}

FUNCTION SOURCE:
{function_string}

Return ONLY the JSON object."""
    response = get_tester_llm().invoke([HumanMessage(content=prompt)])
    data = _extract_json(response.content)
    args = data.get("args", [])
    kwargs = data.get("kwargs", {})
    if not isinstance(args, list) or not isinstance(kwargs, dict):
        raise ValueError("Tester did not return a valid {args, kwargs} call.")
    return {"args": args, "kwargs": kwargs}


# ---------------------------------------------------------------------------
# Nodes
# ---------------------------------------------------------------------------
def call_selection_node(state: HealingState) -> HealingState:
    if state.args_source != "auto_pending":
        _log(state, f"Using caller-supplied call: args={state.args} kwargs={state.kwargs}")
    else:
        _log(state, f"Tester LLM ({state.tester_model or 'configured model'}): selecting a representative call.")
        call = guess_smoke_call(state.function_name, state.function_string)
        state.args = call["args"]
        state.kwargs = call["kwargs"]
        state.args_source = "auto"
        _log(state, f"Auto-selected call: args={state.args} kwargs={state.kwargs}")
    _validate_arity(state.function_string, state.function_name, state.args, state.kwargs)
    return state


def code_execution_node(state: HealingState) -> HealingState:
    _log(state, f"Running {state.function_name}(*{state.args}, **{state.kwargs})...")
    outcome = run_call(state.function_string, state.function_name, state.args, state.kwargs)
    state.error = not outcome["passed"]
    if state.error:
        state.error_description = outcome.get("exception") or "The call did not complete successfully."
        state.status = "running"
        _log(state, f"Call raised: {state.error_description}")
    else:
        state.error_description = ""
        state.status = "success"
        state.result = f"Call succeeded. Result: {outcome.get('actual')!r}"
        _log(state, "Call ran without error.")
    return state


def code_update_node(state: HealingState) -> HealingState:
    state.iterations += 1

    # Best-effort context from past runs. If Chroma is unavailable, this is
    # just an empty list -- it can never fail this node.
    query = f"{state.function_name}: {state.error_description}"
    context = recent_patterns(query)
    context_block = (
        "\nRELATED PAST BUG PATTERNS (context only, may not apply here):\n" + "\n---\n".join(context)
        if context else ""
    )

    prompt = f"""{FIXER_SYSTEM}

CURRENT FUNCTION:
{state.function_string}

FAILING CALL:
args={state.args}
kwargs={state.kwargs}

ERROR:
{state.error_description}
{context_block}

Return ONLY the complete corrected function."""
    response = get_fixer_llm().invoke([HumanMessage(content=prompt)])
    candidate = _strip_code_fences(response.content)
    name, extracted = _extract_function(candidate)
    if name != state.function_name:
        raise ValueError("Fixer changed the function name.")
    state.new_function_string = extracted
    state.status = "awaiting_approval"
    _log(state, f"Fixer LLM ({state.fixer_model or 'configured model'}) proposed repair round {state.iterations}; awaiting human approval.")

    save_bug_pattern(f"# {state.function_name}\n## {state.error_description}")
    return state


def code_patching_node(state: HealingState) -> HealingState:
    """Apply the approved patch only; regression is a separate graph node."""
    _log(state, "Applying human-approved patch...")
    _load_callable(state.new_function_string, state.function_name)
    state.function_string = state.new_function_string
    state.new_function_string = ""
    state.status = "running"
    return state


def regression_node(state: HealingState) -> HealingState:
    """Re-run the SAME call that triggered this repair round."""
    _log(state, "Re-running the failing call against the patched function...")
    outcome = run_call(state.function_string, state.function_name, state.args, state.kwargs)
    state.error = not outcome["passed"]

    if not state.error:
        state.status = "success"
        state.result = f"Patch resolved the failure. Result: {outcome.get('actual')!r}"
        _log(state, state.result)
    else:
        state.error_description = outcome.get("exception") or "The call still does not complete successfully."
        state.status = "running"  # give_up_node overrides this if rounds are exhausted
        _log(state, f"Failure persists after the patch: {state.error_description}")

    return state


def give_up_node(state: HealingState) -> HealingState:
    state.status = "failed_max_iterations"
    state.result = f"Stopped after {state.iterations} repair round(s); the call still fails."
    _log(state, state.result)
    return state


# ---------------------------------------------------------------------------
# Routers
# ---------------------------------------------------------------------------
def initial_router(state: HealingState) -> str:
    return "success" if not state.error else "code_update_node"


def regression_router(state: HealingState) -> str:
    if not state.error:
        return END
    if state.iterations >= state.max_iterations:
        return "give_up_node"
    return "code_update_node"


def build_graph():
    builder = StateGraph(HealingState)
    builder.add_node("call_selection_node", call_selection_node)
    builder.add_node("code_execution_node", code_execution_node)
    builder.add_node("code_update_node", code_update_node)
    builder.add_node("code_patching_node", code_patching_node)
    builder.add_node("regression_node", regression_node)
    builder.add_node("give_up_node", give_up_node)

    builder.set_entry_point("call_selection_node")
    builder.add_edge("call_selection_node", "code_execution_node")
    builder.add_conditional_edges(
        "code_execution_node", initial_router, {"success": END, "code_update_node": "code_update_node"}
    )
    builder.add_edge("code_update_node", "code_patching_node")
    builder.add_edge("code_patching_node", "regression_node")
    builder.add_conditional_edges(
        "regression_node", regression_router,
        {END: END, "code_update_node": "code_update_node", "give_up_node": "give_up_node"},
    )
    builder.add_edge("give_up_node", END)

    return builder.compile(checkpointer=MemorySaver(), interrupt_before=["code_patching_node"])


GRAPH = build_graph()


def make_initial_state(
    function_code: str,
    args: Optional[list] = None,
    kwargs: Optional[dict] = None,
    max_iterations: int = MAX_ITERATIONS_DEFAULT,
) -> HealingState:
    name, function = _extract_function(function_code)
    _load_callable(function, name)  # clear compile error before any LLM work

    provided = args is not None or kwargs is not None
    resolved_args = args if args is not None else []
    resolved_kwargs = kwargs if kwargs is not None else {}
    if provided:
        _validate_arity(function.strip(), name, resolved_args, resolved_kwargs)

    return HealingState(
        function_name=name,
        function_string=function.strip(),
        args=resolved_args,
        kwargs=resolved_kwargs,
        args_source="user" if provided else "auto_pending",
        max_iterations=max_iterations,
    )